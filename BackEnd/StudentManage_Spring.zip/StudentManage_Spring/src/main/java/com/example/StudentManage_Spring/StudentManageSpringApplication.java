package com.example.StudentManage_Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManageSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManageSpringApplication.class, args);
	}

}
